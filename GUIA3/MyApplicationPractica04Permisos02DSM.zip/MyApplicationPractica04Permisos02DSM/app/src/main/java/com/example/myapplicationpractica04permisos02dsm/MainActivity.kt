package com.example.myapplicationpractica04permisos02dsm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ActivityCompat
import android.content.pm.PackageManager
import android.content.pm.PermissionInfo
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val TAG= "Practica 04 - Permisos"
    private val CODIGOSSOLICITUDGRABAR = 101
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configurarPermisos()
    }
    private fun configurarPermisos() {
        val permission =
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
        if (permission != PackageManager.PERMISSION_GRANTED) {
            Log.i(TAG, "Permiso denegado para grabar")
            if
                    (ActivityCompat.shouldShowRequestPermissionRationale(
                    this,android.Manifest.permission.RECORD_AUDIO))

            val builder = AlertDialog.Builder(this)
            builder.setMessage("Permiso para accerder al microfono es requerido por esta app para grabar audio. ")
                .setTitle("Permission required")
            builder.setPositiveButton("OK") { dialog, id ->
                Log.i(TAG, "seleccionado")
                hacerSolicitudPermiso()
            }
            val dialog = builder.create()
            dialog.show()
        } else {
            hacerSolicitudPermiso()
        }
    }

        }
private fun hacerSolicitudPermiso() {
    ActivityCompat.requestPermissions(
        this,
        arrayOf(android.Manifest.permission.RECORD_AUDIO),
        CODIGOSSOLICITUDGRABAR
    )
}
override fun onRequestPermissionsResult(requestCode : Int, Permission: Array<String>, grantResults: IntArray) {
    super.onRequestPermissionsResult(resquestCode, permissions, grantResults)
    when (requestCode){
        CODIGOSSOLICITUDGRABAR -> {
            if (grantResults.IsEmpty() || grantResults[0] !=
            PackageManager.PERMISSION_GRANTED){
                Log.i(TAG, "Permiso a sido denegado por el usuario")

                Toast.makeText(
                    applicationContext,
                    "permiso a sido dengado por el usuario",
                    Toast.LENGTH_SHORT
                ).show()
                /*Escribir codigo de permiso Denegado, segun se requiere */
            } else {
                Log.i(TAG, "Permiso consedido po0r el usuario ")
                Toast.makeText(applicationContext, "permiso consedido por el usuario"
                Toast.LENGTH_SHORT)
                /*escribir codigo de permiso consedido, segun se requiere*/
            }
        }
    }
    }
    }



